# GROW Retail Sales & Profitability Analysis

## Project status
Portfolio project completed using the provided Sample Superstore CSV. This is a public/sample dataset, not verified data from a real GROW company. Present it as a simulated retail business case.

## Business problem
Retail management needs a clear view of sales, profitability, category/region performance, discount patterns, and data quality before making decisions.

## Tools
- Excel: workbook, KPI summary, charts, category/region and monthly analysis
- SQL: reusable business queries in `grow_analysis.sql`
- Python: Pandas data checks, aggregations, and Matplotlib chart generation
- Tableau: interactive retail sales and profitability dashboard built from 12 worksheets, with 4 standalone analytical charts and KPI summaries. The analysis covers sales, profit, profitability, regional performance, category/sub-category performance, and monthly trends.
- Power BI: use the prepared CSV/Excel analysis tables to create an interactive report (dashboard build instructions below)

## Tableau dashboard and analysis
The Tableau work includes one consolidated dashboard supported by 12 worksheets. Four analytical charts are presented separately in the portfolio, while KPI cards remain part of the dashboard rather than being treated as standalone charts. The worksheets cover total profit, total sales, profit margin, orders, negative-profit analysis, monthly sales and profit trends, sales by category, profit by region, profit by sub-category, and regional/sub-category highlight views.

The dashboard is intended to help explore sales and profitability patterns across time, regions, categories, and sub-categories. Findings are descriptive and should not be interpreted as proof of causation.

## Dataset scope
- Rows: 10,194
- Columns: 21
- Order IDs: 5,111 distinct
- Customers: 804 distinct
- Date range in file: 2023-01-03 to 2026-12-30
- Important: this file's date range extends through December 2026. Validate whether this is expected for your assignment before treating it as historical real-world data.

## Results from this file
- Total sales: $2,326,534.35
- Total profit: $292,296.81
- Overall profit margin: 12.56%
- Rows with negative profit: 1,901 (18.65% of line items)
- Missing cells: 0
- Exact duplicate rows: 0
- Duplicate Row ID values: 0
- Ship date earlier than order date: 0

### Insights to investigate
1. Technology has the highest category sales in this file ($839,893.28); compare margin as well as revenue before recommending where to invest.
2. Tables has the lowest total profit among sub-categories ($-17,753.21), despite substantial sales. Investigate discounting, costs, and order mix.
3. Central region has lower total profit than West and East; break down by category and discount before recommending changes.
4. Discount values and profit have a negative relationship in this dataset (Pearson correlation: -0.219). This is descriptive only and does not prove discounts caused losses.
5. Negative-profit line items are not data errors by default. Keep them and investigate why they are unprofitable.

## Power BI dashboard build
1. Open Power BI Desktop and import `GROW_Analytics_Workbook.xlsx`.
2. Select tables/sheets: `KPI_Summary`, `Category_Analysis`, `Region_Analysis`, `Monthly_Trend`, `Subcategory_Profit`, `Discount_Analysis`.
3. Create KPI cards for Total Sales, Total Profit, Profit Margin %, Unique Orders, Unique Customers.
4. Add a line chart: Month on X-axis, Sales and Profit as values.
5. Add bar charts: Sales by Category, Profit by Region, Profit by Sub-Category.
6. Add slicers for Region, Category, Segment, and Order Date. For full interactivity, use `Analysis_Data` and build measures against that single fact table rather than combining pre-aggregated summary sheets.
7. Add a note: “Discount association is descriptive; further analysis is needed to estimate causal impact.”

## Suggested next steps
- Build Power BI report and add screenshots.
- Validate currency and date assumptions.
- Investigate discount levels, product costs, and order mix.
- Add a short recommendations section after reviewing charts.

## Files
- `GROW_Analytics_Workbook.xlsx`: workbook and charts
- `grow_analysis.sql`: SQL examples
- `grow_analysis.py`: reproducible analysis script
- `samplesuperstore.csv`: source data used for this project
